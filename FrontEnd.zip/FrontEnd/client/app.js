var myApp = angular.module('myApp',['ngRoute']);

myApp.config(function($routeProvider)
{
	console.log('I am loaded app.js');
	$routeProvider
			.when('/',{
				controller:'DController',
				templateUrl:'views/home/home.html'
			})
			.when('/home',{
				redirectTo: '/'
			})	
			.when('/input',{
				controller:'IController',
				templateUrl:'views/input/input.html'
			})
			.when('/result',{
				controller:'RController',
				templateUrl:'views/result/result.html'
			})
			.otherwise({
				redirectTo: '/'
			});
});