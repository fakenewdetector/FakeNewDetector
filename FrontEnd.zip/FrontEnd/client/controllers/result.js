var myApp = angular.module('myApp');

myApp.controller('RController',['$timeout', 'storageService','$scope', '$http', '$location', '$routeParams','$interval', function($timeout, storageService, $scope, $http, $location, $routeParams,$interval)
{
	console.log('RController is now loaded....');

	$scope.percentage1 = "0%";
	$scope.percentage2 = "0%";
	$scope.percentage3 = "0%";
	$scope.percentage4 = "0%";

	$scope.__showProgress = function (_upto) {
		console.log('I am called')
		console.log(_upto);

		//Filter Percentage
		_upto = (_upto > 100) ? 100 : ((_upto < 0) ? 0 : _upto);

		var _progress = 0;

		var _cir_progress = angular.element(document.querySelector('#_cir_P_y1'));
		var _text_percentage = angular.element(document.querySelector('#_cir_Per1'));

		var _input_percentage;
		var _percentage;

		var _sleep = $interval(function () {
			$scope._animateCircle();
		}, 25);

		$scope._animateCircle = function () {

			_input_percentage = (_upto / 100) * 382;
			_percentage = (_progress / 100) * 382;

			if (_percentage >= _input_percentage) {

				clearInterval(_sleep);
			} else {

				_progress++;

				$scope.percentage1 = _progress + "%";

				_cir_progress[0].style.strokeDasharray = _percentage + ', 1000';
			}
		}
	};

	$scope.getResult = function()
	{
		// put all circle in waiting position => infinite loop
		start('clickbait', 'CBprocent','royalblue', 'royalblue');
		start('satire', 'Sprocent','red', 'red');
		start('collaborativeValidity', 'CVprocent','grey', 'grey');
		start('final', 'Fprocent','green', 'green');

		// access the news from storageService
		$scope.news = storageService.get('news');
		$scope.news = JSON.parse($scope.news);
		console.log($scope.news);

		redirection = "api/Detection";
		console.log("redirecting : " + redirection);

		// Make a Post Request
		$http.post(redirection, $scope.news)
			.then(function(response)
			{	
				console.log('Response');
				console.log(response.data);
				
				// getting the clickbait Percentage
				$scope.clickBaitPercentage = response.data.clickBaitPercentage;

				// identify that percentage has been set
				$scope.isPercentageSet = true;

				// store the result in StorageService (in case to use them on different pages)
				storageService.set('isPercentageSet',$scope.isPercentageSet);
				storageService.set('clickBaitPercentage',$scope.clickBaitPercentage);				

				// Check the output on Console
				console.log($scope.clickBaitPercentage);
	
				console.log('Getting result From Local Storage');
				$scope.isPercentageSet = storageService.get('isPercentageSet');
				$scope.clickBaitPercentage = storageService.get('clickBaitPercentage');
				console.log($scope.clickBaitPercentage);

				$scope.satirePercentage = 60.54
				$scope.VC = 80.54
				$scope.final = ($scope.clickBaitPercentage + $scope.satirePercentage + $scope.VC)/3.0
				

				var timeduration = 6000;
				/* 
				*	stop the circle from spinning
				*/
				remove("clickbait","spinner");
				move('clickbait', 'CBprocent','royalblue', 'royalblue', $scope.clickBaitPercentage);
				// satire
				setTimeout(function(){remove("satire","spinner")}, timeduration*1.5);
				setTimeout(function(){move('satire', 'Sprocent','black', 'black', $scope.satirePercentage)}, timeduration*1.5);
				// CV
				setTimeout(function(){remove("collaborativeValidity","spinner")}, timeduration*2);
				setTimeout(function(){move('collaborativeValidity', 'CVprocent','grey', 'grey', $scope.VC)}, timeduration*2);
				// final
				setTimeout(function(){remove("final","spinner")}, timeduration*2.5);
				if ($scope.final < 50) {
					setTimeout(function(){move('final', 'Fprocent','red', 'red', $scope.final)}, timeduration*2.5);
				}
				else {
					setTimeout(function(){move('final', 'Fprocent','green', 'green', $scope.final)}, timeduration*2.5);								
				}

				// FYP 1 animated circle
				//$scope.__showProgress($scope.clickBaitPercentage)				
			});	
	}
}]);