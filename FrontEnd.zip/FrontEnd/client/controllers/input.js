var myApp = angular.module('myApp');

myApp.controller('IController',['storageService','$scope', '$http', '$location', '$routeParams', '$timeout','$route', function(storageService, $scope, $http, $location, $routeParams, $timeout, $route){
	console.log('IController is now loaded....');


	$scope.isPercentageSet = false;
	$scope.clickBaitPercentage = 0;
	
	$scope.addnews = function(url)
	{
		console.log($scope.news);
		$http.post(url, $scope.news)
			.then(function(response){
				window.location.href = '#!/input';	
			});	
	}

	$scope.detectClickBait = function()
	{
		/*
		storageService.set('title',$scope.title);
		console.log($scope.title);
		window.location.href = "#!/result";
		*/

		console.log($scope.news);
		storageService.set('news',JSON.stringify($scope.news));
		window.location.href = "#!/result";

		// url = "api/detection/" + $scope.title
		// console.log($scope.title);
		// console.log(url)

		// $http.get(url)
		// 	.then(function(response)
		// 	{
		// 		$scope.clickBaitPercentage = response.data.percentage;
		// 		$scope.isPercentageSet = true;
		// 		storageService.set('isPercentageSet',$scope.isPercentageSet);
		// 		storageService.set('clickBaitPercentage',$scope.clickBaitPercentage);				
		// 		console.log($scope.clickBaitPercentage);
		// 		window.location.href = "#!/result";				
		// 	});	

	}



}]);