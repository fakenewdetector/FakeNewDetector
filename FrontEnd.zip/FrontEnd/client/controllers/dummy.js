var myApp = angular.module('myApp');

myApp.controller('DController',['$scope', '$http', '$location', '$routeParams', function($scope, $http, $location, $routeParams){
	console.log('DController is now loaded....');

	$scope.input = function()
	{
		window.location.href = "#!/input";
	}

	$scope.get= function(url){
		$http.get(url)
			.then(function(response){
				// Now we can use 'genre' in our views
			});	
	}
	$scope.get = function(url){
		var id = $routeParams.id;
		$http.get(url+id)
			.then(function(response){
				$scope.book = response;
			});	
	}

}]);	