var myApp = angular.module('myApp');

myApp.factory('storageService', ['$rootScope', function($rootScope) {

    console.log('storageService is loading now......')

    return {
        get: function(key) {
            return localStorage.getItem(key);
        },
        set: function(key, data) {
            localStorage.setItem(key, data);
        }
    };
}]);


// storageService.set('key','value');
// storageService.get('key');