/*
* remove the class who have the mentioned ID
* useful for animated circles on result page
* remove the infinite loop from circle after getting result
*/
function remove(id,classs) {
    node = document.getElementById(id).classList.remove(classs)
}

/*
* redirect to the result page
*/
function result(){
  window.location.assign("#!/result");
}

/*
* refresh page 
*/
function refresh() {
    location.reload();
}


function enableDatePicker() {
    document.getElementById('from').disabled = !document.getElementById('from').disabled;
    document.getElementById('to').disabled = !document.getElementById('to').disabled;
}

function enableAdvanceOption(){
    if (document.getElementById('advanceoption').style.display == "block") {
        document.getElementById('advanceoption').style.display = "none";        
    }    
    else {
        document.getElementById('advanceoption').style.display = "block";
    }
}