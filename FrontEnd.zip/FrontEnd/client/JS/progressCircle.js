function move(CanvasId, markUpPercentage, barColor, percentageColor, percentage) {

    // get the node of give Canvas Id
    var can = document.getElementById(CanvasId),
        spanProcent = document.getElementById(markUpPercentage),
        c = can.getContext('2d');
    
    var posX = can.width / 2,
        posY = can.height / 2,
        fps = 1000 / 200,
        procent = 0,
        oneProcent = 360 / 100,
        result = oneProcent * percentage;
    
    c.lineCap = 'round';
    arcMove();
    
    function arcMove(){
    var deegres = 0;
    var acrInterval = setInterval (function() {
        deegres += 1;
        c.clearRect( 0, 0, can.width, can.height );
        procent = deegres / oneProcent;

        spanProcent.innerHTML = procent.toFixed();
        spanProcent.style.color = percentageColor;
        //spanProcent.style.visibility = true;

        c.beginPath();
        c.arc( posX, posY, 70, (Math.PI/180) * 270, (Math.PI/180) * (270 + 360) );
        c.strokeStyle = '#b1b1b1'; // color of border
        c.lineWidth = '10';
        c.stroke();

        c.beginPath();
        // c.strokeStyle = '#3949AB';
        //c.strokeStyle = '#187E6A';  
        c.strokeStyle = barColor;  // color of progress bar on circle
        c.lineWidth = '10';
        c.arc( posX, posY, 70, (Math.PI/180) * 270, (Math.PI/180) * (270 + deegres) );
        c.stroke();
        if( deegres >= result ) clearInterval(acrInterval);
    }, fps);
    
    }
}	


function start(CanvasId, markUpPercentage, barColor,percentageColor) {

    // get the node of give Canvas Id
    var can = document.getElementById(CanvasId),
        spanProcent = document.getElementById(markUpPercentage),
        c = can.getContext('2d');
    
    var posX = can.width / 2,
        posY = can.height / 2,
        fps = 1000 / 200,
        procent = 0,
        oneProcent = 360 / 100,
        result = oneProcent * 15;
    
    c.lineCap = 'round';
    arcMove();
    
    function arcMove(){
    var deegres = 0;
    var acrInterval = setInterval (function() {
        deegres += 1;
        c.clearRect( 0, 0, can.width, can.height );
        procent = deegres / oneProcent;

        spanProcent.style.color = percentageColor;        

        c.beginPath();
        c.arc( posX, posY, 70, (Math.PI/180) * 270, (Math.PI/180) * (270 + 360) );
        c.strokeStyle = '#b1b1b1'; // color of border
        c.lineWidth = '10';
        c.stroke();

        c.beginPath();
        // c.strokeStyle = '#3949AB';
        //c.strokeStyle = '#187E6A';  
        c.strokeStyle = barColor;  // color of progress bar on circle
        c.lineWidth = '10';
        c.arc( posX, posY, 70, (Math.PI/180) * 270, (Math.PI/180) * (270 + deegres) );
        c.stroke();
        if( deegres >= result ) clearInterval(acrInterval);
    }, fps);
    
    }
}	