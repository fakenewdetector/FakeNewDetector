// Import Node Express
var express = require('express');
var bodyParser = require('body-parser');
var request = require('request');
var EventEmitter = require("events").EventEmitter;


var app = express();
app.use(express.static(__dirname+'/client'));
app.use(bodyParser.json());


// FLASK SERVER CONFIGURATION
F_server_host = 'localhost';
F_server_port = '5000';
F_server_url = "http://" + F_server_host + ":" + F_server_port;

// set the default variable in local Storage

// Home Page
app.get('/',function(req,resp)
{
	resp.send(`
		<html>
			<body>
				<h1>WELCOME</h1>
				<p>
					Fake News Detection
				</p>
			</body>
		</html>
	`);
});

/*
	Detection API
*/

app.post('/api/Detection/',function(req,resp, next)
{
	var body = new EventEmitter();

	var news = req.body;
	console.log('Processing New : ');
	console.log(news);
	console.log(typeof(news));
	
	// Flask web server Address to send ClickBait Detection request
	redirecting = F_server_url + '/Detection/';
	console.log('Redirecting the Request at : ' + redirecting);	

	// Forward Request to Flask Web Server
	// 		embed data/input in Json Format for Post request
	
	const options = {
		method : 'POST',
		uri: redirecting,
		body : news,
		json : true
	}

	request(options, function(error, response,data) {
			body.data = data;
			body.emit('update');
		});

	body.on('update', function () 
	{
	    console.log(body.data); 

		// Send the Json Response Back to Angular
		resp.json(body.data);
	});
});


server = "localhost"
port = "4004"

app.listen(port);
console.log('Server is running on ' + server + " at " + port);